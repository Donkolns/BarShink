<?php
session_start();
require_once 'connect.php';
if (isset($_SESSION["message"])) {
    $mes = $_SESSION["message"];
    echo "<script>alert('$mes')</script>";
    unset($_SESSION["message"]);
}
$cart = [];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>BarShik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Слайдер -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
</head>

<body>
    <?php require_once "header.php" ?>
    <main>
        <div class="catalog">
            <h2>Каталог</h2>
            <div class="category">
                <button class="button-category">Энергетики</button>
                <button class="button-category">Газировки</button>
                <button class="button-category">Соки</button>
                <button class="button-category">Вода</button>
                <button class="button-category">Чаи</button>
                <button class="button-category">Кофе</button>
            </div>
            <div class="bloc-drinks">
                <div class="drink">
                    <?php
                    $res = mysqli_query($con, "SELECT * FROM product JOIN category ON product.Category_id = category.Category_id");
                    while ($row = mysqli_fetch_assoc($res)) {
                    ?>
                        <div class="tovar">
                            <img class="img_tovr" src="images/<?= $row["Image"] ?>" alt="">
                            <h4><?= $row["Name"] ?></h4>
                            <p><?= $row["Price"] ?> руб.</p>
                            <?php if (isset($_SESSION["User_id"])) { ?>
                                <a href="add_basket.php?id_product=<?= $row['Id_product'] ?>">
                                    <button class="button-tovar btn-add-cart" value="<?= $row['Id_product'] ?>">Добавить в корзину</button>
                                </a>
                            <?php } ?>
                        </div>
                    <?php } ?>
                </div>
            </div>
            <a href="/catalog.php"><button class="podrobnee">Подробнее</button></a>
        </div>
        <!-- Описание -->
        <div class="description">
            <div class="text-description">
                <h3>Закажите напитки к себе домой</h3>
                <p> Жажда движения? Цените качество без компромиссов?</p>
                <p> Мы предлагаем широкий выбор напитков, которые идеально подойдут для вашего активного образа жизни!
                    Прохладная газировка, натуральные соки, ароматный кофе или чай — выбирайте то, что нужно именно вам.</p>
            </div>
            <div class="bloc-img-description">
                <img src="images/Group 8192.png" alt="" class="logo">
                <img src="images/Group 8195.png" alt="" class="img-description">
            </div>
        </div>
        <!-- Отзывы -->
        <div class="reviews">
            <h2 class="text-reviews">Отзывы</h2>
            <div class="slider">
                <div class="slide">
                    <div class="otzv">
                        <img class="user-img" src="images/free-icon-boy-4537069.png" alt="">
                        <p>Этот кофе - просто открытие! Аромат сводит с ума, вкус насыщенный и глубокий. Отдельное спасибо
                            за стильную упаковку - приятно даже просто держать в руках. Однозначно буду заказывать еще и всем советую побаловать себя чашечкой этого волшебства!</p>
                    </div>
                    <div class="otzv">
                        <img class="user-img" src="images/free-icon-boy-4537069.png" alt="">
                        <p>Настоящий подарок для ценителей кофе! Насыщенный аромат раскрывается с первой секунды, а вкус...
                             Это просто взрыв кофейных нот! Удобная упаковка позволяет сохранить всю свежесть и аромат. С уверенностью могу рекомендовать этот кофе всем любителям!</p>
                    </div>
                    <div class="otzv">
                        <img class="user-img" src="images/free-icon-boy-4537069.png" alt="">
                        <p>Отличный кофе! Ароматный, насыщенный, бодрящий - все, что нужно для идеального утра (или дня!). Упаковка выше всяких похвал. Буду брать еще!</p>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- Подвал -->
    <footer id="footer">
        <div class="container">
            <div class="connection">
                <div class="connect">
                    <p>Связь с нами</p>
                    <div class="images-connection">
                        <img src="images/tg.png" alt="" class="icon-rutube">
                        <img src="images/icons8-vk-com-48.png" alt="">
                        <img src="images/iconfinder-social-media-applications-23whatsapp-4102606_113811.png" class="icon-whatsapp">
                    </div>
                </div>
                <div class="clock-work">
                    <p>Часы работы:</p>
                    <p>12:00 - 22:00</p>
                </div>
            </div>
            <hr>
            <p class="copirater">© 2023 Копирование запрещено. Все права защищены.</p>
        </div>
    </footer>
    <script>
        const slider = document.querySelector('.slider');
        const slides = document.querySelectorAll('.slide');
        let currentSlide = 0;

        function nextSlide() {
            slides[currentSlide].style.display = 'none';
            currentSlide = (currentSlide + 1) % slides.length;
            slides[currentSlide].style.display = 'flex';
        }
    </script>
</body>

</html>
