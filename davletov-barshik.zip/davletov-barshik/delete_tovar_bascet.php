<?php
session_start();
require_once "connect.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_user = $_SESSION["User_id"];

    $query = "DELETE FROM basket WHERE User_id = '$id_user'";
    $result = mysqli_query($con, $query);

    if ($result) {
        // Очищаем корзину в сессии
        unset($_SESSION["cart"]);
        $_SESSION["message"] = "Корзина успешно очищена.";
    } else {
        $_SESSION["message"] = "Ошибка при очистке корзины.";
    }

    header("Location: cart.php");
    exit();
} else {
    // Если метод не POST, перенаправляем обратно на страницу корзины
    header("Location: cart.php");
    exit();
}
?>
