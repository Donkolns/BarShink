<?php
include "../connect.php";

// Получение категорий для выпадающего списка
$categoryQuery = "SELECT * FROM Category";
$categoryResult = mysqli_fetch_all(mysqli_query($con, $categoryQuery));

// Инициализация переменных для фильтра, сортировки и поиска
$filter = isset($_GET["filter"]) ? $_GET["filter"] : "";
$sort = isset($_GET["sort"]) ? $_GET["sort"] : "";
$search = isset($_GET["search"]) ? $_GET["search"] : "";

// Построение SQL-запроса в зависимости от условий
$filterSearch = "";
if (!empty($search)) {
    $filterSearch .= " WHERE Product.Name LIKE '%" . $search . "%'";
}
if (!empty($filter)) {
    if (empty($filterSearch)) {
        $filterSearch .= " WHERE Product.category_id=" . $filter;
    } else {
        $filterSearch .= " AND Product.category_id=" . $filter;
    }
}
if (!empty($sort)) {
    $sort = " ORDER BY Product.price " . $sort;
} else {
    $sort = " ORDER BY Product.category_id";
}

$query = "SELECT * FROM Product
    INNER JOIN Category ON Category.category_id = Product.category_id
    " . $filterSearch . $sort;

$result = mysqli_query($con, $query);
$list_products = mysqli_fetch_all($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <nav class="nav">
            <div class="index">
                <h1 class="index_">Админ</h1>
            </div>
            <div class="cart_account">
                <a href="newTovar.php">Управление товарами</a>
                <a href="categoryTovar.php">Управление категориями напитков</a>
                <a href="orderManagement.php">Управление заказами</a>
                <a href="Panel-admin5.php">Статистика и отчеты</a>
                <a href="../signout.php">Выйти</a>
            </div>
        </nav>
    </header>
    <!-- фильтр , сортировка и поиск -->
    <p class="centered-text p-ne-t">Управление товарами</p>
    <div class="filter-products">
        <form method="get">
            <input type="text" placeholder="Поиск" name="search" <?php if (!empty($search)) { echo "value=" . $search; } ?>>
            <select name="filter" id="">
                <option value="" <?php if (empty($filter)) { echo " selected"; } ?>>Все категории</option>
                <?php foreach ($categoryResult as $item) : ?>
                    <option value="<?= $item[0] ?>" <?php if ($item[0] == $filter) { echo " selected"; } ?>><?= $item[1] ?></option>
                <?php endforeach; ?>
            </select>
            <select name="sort" id="">
                <option value="" <?php if (empty($sort)) { echo " selected"; } ?>>Цена</option>
                <option value="ASC" <?php if ($sort == "ASC") { echo " selected"; } ?>>По возрастанию</option>
                <option value="DESC" <?php if ($sort == "DESC") { echo " selected"; } ?>>По убыванию</option>
            </select>
            <button type="submit">Отправить</button>
        </form>
    </div>
    <div class="container">
        <div class="products">
            <table>
                <tr>
                    <th>Название</th>
                    <th>Категория</th>
                    <th>Цена</th>
                    <th>Описание</th>
                    <th>Миниатюра</th>
                    <th>Редактировать</th>
                    <th>Удалить</th>
                </tr>
                <form action="product_update.php" method="post">
                <?php foreach ($list_products as $item): ?>
                    <input type="hidden" name="Idp" value="<?= $item[0] ?>">
                    <tr>
                        <td><input type="text" name="Name" value="<?= $item[1] ?>"></td>
                        <!-- Выпадающий список для категории --> 
                        <td>
                            <select name="Categ">
                                <?php foreach ($categoryResult as $categoryItem): ?>
                                    <option value="<?= $categoryItem[0] ?>" <?= $categoryItem[0] == $item[3] ? 'selected' : '' ?>>
                                        <?= $categoryItem[1] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td><input type="text" name="Price" value="<?= $item[4] ?>"></td>
                        <td><input type="text" name="Descr" value="<?= $item[2] ?>"></td>
                        <td><img src="../images/<?= $item[5] ?>" alt="" class="img-product-admin"></td>
                        <td><input type="submit" value="Редактировать"></td>
                    </form>
                    <td><a class="btn btn-danger" href='product-delete.php?item=<?= $item[0] ?>'>Удалить</a></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <div>
            <h2 class="edit-tovar">Добавление товара</h2>
            <form action="newTovar_db.php" class="adding" method="POST">
                <input type="text" name="Name" placeholder="Название">
                <select name="Categ" id="category">     
                <?php foreach ($categoryResult as $item) { ?>  
                    <option value='<?= $item[0] ?>'><?= $item[1]; ?></option>  
                <?php } ?>  
                </select>
                <input type="text" name="Price" placeholder="Цена">
                <input type="text" name="Descr" placeholder="Описание">
                <input type="text" name="Image" placeholder="Изображение">
                <button type="submit" class="btn btn-success">Создать</button>
            </form>
        </div>
    </div>
</body>
</html>
