<header  content="width=device-width, initial-scale=1">
    <div class="container">
        <div class="naw-header">
            <img src="images\Group 8192.png" alt="" class="logo">
            <h1>BarShik</h1>
            <div class="naw-menu">
                <a href="/">Главная</a>
                <a href="">Каталог</a>
                <a href="">Корзина</a>
                <a href="#footer">Контакты</a>
                <a href="auto.php">Войти</a>
            </div>
        </div>
    </div>
</header>